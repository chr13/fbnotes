#!/bin/sh

#should check for both /1.1 and /1.0, 2 requests for 1 <img> tag

# Requests
echo "Requests:"
cat access.log | grep "facebookexternalhit/1.1" | wc -l

echo "\nUnique Servers:"
# Number of unique servers
cat access.log | grep "facebookexternalhit/1.1" | awk '{ print $1 }' | sort -u | wc -l



